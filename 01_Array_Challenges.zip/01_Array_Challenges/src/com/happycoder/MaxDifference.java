package com.happycoder;

import java.util.Arrays;
import java.util.Scanner;

// Program - 5
public class MaxDifference {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter no. of elements you want in array : ");
		int num = sc.nextInt();
		
		int array[] = new int[num];
		
		System.out.println("Enter elements in array : ");
		for(int i=0; i<num; i++) {
			array[i] = sc.nextInt();
		}
		
		System.out.println("Array is : " + Arrays.toString(array));
		
		int minEle = array[0];
		int maxEle = array[0];
		
		for(int j = 0; j<array.length; j++) {
			minEle = Math.min(minEle, array[j]);
			maxEle = Math.max(maxEle, array[j]);
		}
		
		System.out.println("Max difference between " + minEle + " and " + maxEle + " is " + (maxEle - minEle));
		
		

	}

}
