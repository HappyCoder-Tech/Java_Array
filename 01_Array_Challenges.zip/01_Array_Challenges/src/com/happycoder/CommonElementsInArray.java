package com.happycoder;

import java.util.Arrays;
import java.util.Scanner;

public class CommonElementsInArray {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int i = 0 ,j = 0 , k=0;
		
		System.out.println("Enter no. of elements you want in array1 : ");
		int num1 = sc.nextInt();
		
		int array1[] = new int[num1];
		
		System.out.println("Enter elements in array1 : ");
		for(int x=0; x<num1; x++) {
			array1[x] = sc.nextInt();
		}
		
		System.out.println("Enter no. of elements you want in array2 : ");
		int num2 = sc.nextInt();
		
		int array2[] = new int[num2];
		
		System.out.println("Enter elements in array2 : ");
		for(int x=0; x<num2; x++) {
			array2[x] = sc.nextInt();
		}
		
		System.out.println("Enter no. of elements you want in array3 : ");
		int num3 = sc.nextInt();
		
		int array3[] = new int[num3];
		
		System.out.println("Enter elements in array3 : ");
		for(int x=0; x<num3; x++) {
			array3[x] = sc.nextInt();
		}
		
		System.out.println("Array 1 is : " + Arrays.toString(array1));
		System.out.println("Array 2 is : " + Arrays.toString(array2));
		System.out.println("Array 3 is : " + Arrays.toString(array3));
		
		Arrays.sort(array1);
		Arrays.sort(array2);
		Arrays.sort(array3);
		
		System.out.println("Common elements in 3  array are :  ");
		
		while(i < array1.length && j < array2.length && k < array3.length) {
			if(array1[i] == array2[j] && array2[j] == array3[k]) {
				System.out.println(array1[i] + " ");
				i++;
				j++;
				k++;
			}else if(array1[i] < array2[j]) {
				i++;
			}else if(array2[j] < array3[k]) {
				j++;
			}else {
				k++;
			}
		}
		
		
	}

}
