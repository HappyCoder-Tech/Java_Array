package com.happycoder;

import java.util.Scanner;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;

//Program -7
public class SecondMinMaxInArray {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Set<Integer> set = new HashSet<>();
		
		System.out.println("Enter no. of elements in array : ");
		int num = sc.nextInt();
		
		System.out.println("Enter elements n array : ");
		for(int i=0; i<num; i++) {
			set.add(sc.nextInt());
		}
		
		Object array[] = set.toArray();
		Arrays.sort(array);
		
		System.out.println("Second min element in array : "+ array[1]);
		System.out.println("Second max element in array : "+ array[array.length - 2]);
	}

}
