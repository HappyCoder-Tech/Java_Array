package com.happycoder;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

// Program -1
public class DuplicateElementsInArray {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Set<Integer> set = new HashSet<>();
		
		System.out.println("Enter no. of elements you want in array : ");
		int num = sc.nextInt();
		
		int array[] = new int[num];
		
		System.out.println("Enter elements on array : ");
		
		for(int i=0; i<num; i++) {
			array[i] = sc.nextInt();
		}
		
		for(int i = 0; i<array.length; i++) {
			for(int j = i+1; j<array.length; j++) {
				if(array[i] == array[j]) {
					set.add(array[i]);
				}
			}
		}
		
		if(set.size()>0) {
			System.out.println("Duplicate elements in array : " + set.toString());
		}else {
			System.out.println("No duplicate elemets found in array ");
		}
	}
	
	
}
