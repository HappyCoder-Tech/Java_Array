package com.happycoder;

import java.util.Scanner;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;

// Program -10
public class SmallestSum {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Set<Integer> set = new HashSet<Integer>();

		System.out.println("Enter no. of elements you want in array : ");
		int num = sc.nextInt();

		int array[] = new int[num];

		System.out.println("Enter array elements : ");
		for(int i = 0; i < num; i++) {
			array[i] = sc.nextInt();
		}

		Arrays.sort(array);
		int min = array[0];
		int secondMin = array[1];
		int sum = min + secondMin;

		System.out.println("Smallest pair is : (" + min + " , " + secondMin + ")" + " Sum is : " + sum);

	}
}
