package com.happycoder;

import java.util.Scanner;

//Program - 9
public class SumOfPairs {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter no. of elements you want in array : ");
		int num = sc.nextInt();
		
		int array[] = new int[num];
		
		System.out.println("Enter Sum : ");
		int inputSum = sc.nextInt();
		
		System.out.println("Enter elements in array : ");
		for(int i = 0; i < num; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println("Pairs with sum are : ");
		for(int j = 0; j < array.length; j++) {
			for(int k = j+1; k < array.length; k++) {
				if(array[j] + array[k] == inputSum) {
					System.out.println(array[j] + " + " + array[k] + "=" + inputSum);
				}
			}
		}
	}

}
