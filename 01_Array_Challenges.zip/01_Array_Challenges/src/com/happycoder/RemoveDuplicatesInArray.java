package com.happycoder;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

//Program -2
public class RemoveDuplicatesInArray {
	
	public static void main(String[] args) {
		
		Set<Integer> set = new HashSet<>();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter no. of elements you want in array : ");
		int size = sc.nextInt();
		
		System.out.println("Enter array elements : ");
		for (int i = 0; i < size; i++) {
			set.add(sc.nextInt());
		}
		
		System.out.println("Array after removing duplicates : "+ Arrays.toString(set.toArray()));
	}

}
