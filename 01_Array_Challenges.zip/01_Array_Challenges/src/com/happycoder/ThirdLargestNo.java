package com.happycoder;

import java.util.Scanner;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;

//Program -4
public class ThirdLargestNo {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		Set<Integer> set = new HashSet<>();
		int max = 0;
		
		System.out.println("Enter no. of elements you want in array : ");
		int num = sc.nextInt();
		
		System.out.println("Enter elements on array : ");
		for(int i=0; i<num; i++) {
			set.add(sc.nextInt());
		}
		
		if(num >= 3) {
			Object[] arr = set.toArray();
			Arrays.sort(arr);
			System.out.println("Array After sorting : "+ Arrays.toString(arr));
			int size = arr.length;
			max = (int) arr[size-3];
			System.out.println("Third largest no. in array : " + max);
		}else {
			System.out.println("Invalid input, array size is less than 3");
		}
	}

}
