package com.happycoder;

import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.HashSet;

//Program -3
public class CalculateSum {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		Set<Integer> set = new HashSet<>();
		int sum = 0;
		
		System.out.println("Enter no. of elements you want in array : ");
		int size = sc.nextInt();
		
		System.out.println("Enter array elements : ");
		for(int i=0; i<size; i++) {
			set.add(sc.nextInt());
		}
		
		System.out.println("Unique elements in array are : ");
		System.out.println("Array After sorting : "+ Arrays.toString(set.toArray()));
		
		System.out.println("Sum of unique array elements :");
		sum = set.stream().collect(Collectors.summingInt(e -> e.intValue()));
		System.out.println(sum);
	}

}
