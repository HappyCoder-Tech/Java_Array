package com.happycoder;
import java.util.Scanner;
import java.util.Set;
import java.util.Arrays;
import java.util.HashSet;

//Program -6
public class MinMaxInArray {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		Set<Integer> set = new HashSet<>();
		
		System.out.println("Enter no. of elements you want in array : ");
		int num = sc.nextInt();
		
		System.out.println("Enter elements in array : ");
		for(int i=0; i<num; i++) {
			set.add(sc.nextInt());
		}
		
		Object[] arr = set.toArray();
		Arrays.sort(arr);
		System.out.println("Min element in Array : "+ arr[0]);
		System.out.println("Max element in Array : "+ arr[arr.length-1]);
	}

}
